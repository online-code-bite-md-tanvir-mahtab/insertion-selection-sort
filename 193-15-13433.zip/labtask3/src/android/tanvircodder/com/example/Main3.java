package android.tanvircodder.com.example;

import java.util.Arrays;
import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // write your code here
        System.out.println("Enter the amount of the element you went to import : ");
        int size = input.nextInt();
//        now i am going to ask the user to insert some array..///
        int[] arr = new int[size];
        for (int i = 0;i < arr.length; i++){
            arr[i] = input.nextInt();
        }
        System.out.println("Now i am goiing to print out the list : ");
        for (int arrays : arr){
            System.out.println(arrays);
        }

        System.out.println("\n\nDoing the logic of the insertion sort algorithm : \n\n\n");
        for (int step = 1; step < size; step++) {
            int key = arr[step];
            int j = step - 1;

            // Compare key with each element on the left of it until an element smaller than
            // it is found.
            while (j >= 0 && key > arr[j]) {
                arr[j + 1] = arr[j];
                --j;
            }

            // Place key at after the element just smaller than it.
            arr[j + 1] = key;
        }
        System.out.println("The array in assending array:" + Arrays.toString(arr));
        for (int i = 1; i < size; i++){
            int key = arr[i];
            int j = i - 1;
            while (j > 0 && key < arr[j]){
                arr[j + 1] = arr[j];
                --j;
            }
            arr[j+1] = key;
        }
        System.out.println("The arryy desencing array: " + Arrays.toString(arr));


        System.out.println("\n\n doing the binary search logic : \n \n");
        int low ;
        int high;
        int mid;
        // TODO: 1/23/2021 print out the list of array...//
        for (int i =0; i<arr.length;i++){
            System.out.println(arr[i]);
        }
        //now to store the value to an integer wef are goint to create an integer variable called search key...//
        System.out.println("Enter the number that you went to search");
        int searchKey = input.nextInt();
        /*initializing the mid low and high variable*/
//        for the low
        low =0;
        high =size -1;
        while (low <= high){
            mid = (low + high)/2;
            if (searchKey == arr[mid]){
                System.out.println("the array :" + arr[mid] + " the index is :" + mid);
                break;
            }else if (searchKey > arr[mid]){
                low = mid + 1;
            }else {
                high  = mid -1;
            }
        }
    }
}
