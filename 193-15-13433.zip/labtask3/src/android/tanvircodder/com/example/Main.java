package android.tanvircodder.com.example;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
	// write your code here
        System.out.println("Enter the amount of the element you went to import : ");
        int size = input.nextInt();
//        now i am going to ask the user to insert some array..///
        int[] arr = new int[size];
        for (int i = 0;i < arr.length; i++){
            arr[i] = input.nextInt();
        }
        System.out.println("Now i am goiing to print out the list : ");
        for (int arrays : arr){
            System.out.println(arrays);
        }

        System.out.println("\n\nDoing the logic of the selection sort algorithm : \n\n\n");

//        declaring the min_number vareable and temp number variable..//

        for (int i =0; i < arr.length-1;  i++){
            int min_num;
            int temp;
            min_num = i;
            for (int j = i+1;j<arr.length;j++){
                if (arr[i] > arr[j]){
                    min_num = j;
                }
            }
            temp = arr[i];
            arr[i] = arr[min_num];
            arr[min_num] = temp;
        }
        System.out.println("In accending order :"+Arrays.toString(arr));

        for (int i =0;i<arr.length;i++){
            int max_number;
            int temp;
            max_number = i;
            for (int j = i+1;j<arr.length;j++){
                if (arr[i]<arr[j]){
                    max_number = j;
                }
            }
            temp = arr[i];
            arr[i] = arr[max_number];
            arr[max_number] = temp;
        }
        System.out.println("In decending order :" + Arrays.toString(arr));
    }
}
