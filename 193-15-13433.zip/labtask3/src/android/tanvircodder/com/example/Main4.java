package android.tanvircodder.com.example;

import java.util.Arrays;
import java.util.Scanner;

public class Main4 {
    public static void main(String[] args) {
        /*Scanner inpuut = new Scanner(System.in);
        System.out.println("Enter the index number :\n");
        int index = inpuut.nextInt();
        String[] arr = new String[index];
        for (int i =0;i<arr.length;i++){
            arr[i] = inpuut.nextLine();
        }
        System.out.println("The list of name :\n");
        for (String arrays: arr){
            System.out.println( arrays);
        }*/
        String[] arr = {"tanvir","toufiq","koko","firoz"};
        for (String array: arr){
            System.out.println(array);
        }

        System.out.println("\n\nDoing the logic of the selection sort algorithm : \n\n\n");

//        declaring the min_number vareable and temp number variable..//

        for (int i =0; i < arr.length-1;  i++){
            int minIndex = i;
            String  min_num;
            String temp;
            min_num = arr[i];
            for (int j = i+1;j<arr.length;j++){
                if (arr[j].compareTo(min_num)<0){
                    min_num = arr[j];
                    minIndex = j;
                }
            }
            temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
        System.out.println("In accending order :"+ Arrays.toString(arr));
        for (int i = 0; i < arr.length -1;i ++){
            int maxIndex
        }

        Scanner input = new Scanner(System.in);
//        now i am going to do the other logic...//
        System.out.println("Doing the logic of binary search :");
        String searchKey =input.nextLine();
        int low ;
        int high;
        int mid;
        /*nwo i am going to inixilize the 0 and size-1 of the array to the variable*/
        low = 0;
        high = arr.length - 1;
        while (low <= high){
            mid = (low + high)/2;
            if (arr[mid].contains(searchKey)){
                System.out.println("the array name : " + arr[mid] + "the index is " + mid);
                break;
            }else if (searchKey.length()>arr[mid].length()){
                low = mid + 1;
            }else {
                high = mid -1;
            }
        }

    }
}
